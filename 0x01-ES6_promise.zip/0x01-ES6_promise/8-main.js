import divideFunction from './8-try';

console.log(divideFunction(10, 2));
console.log(divideFunction(10, 0));